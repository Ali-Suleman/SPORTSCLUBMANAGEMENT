/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sportsclubmanagement;

import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author saleem
 */
public class PLAYERPURPOSE extends javax.swing.JFrame {

    /**
     * Creates new form PLAYERPURPOSE
     */
    public PLAYERPURPOSE() {
        initComponents();
        this.setResizable(false);
        jPanel2.setVisible(false);
        jPanel3.setVisible(false);
        crickettable();
        footballtable();
        hockeytable();
        swimmingtable();
        badmintontable();
        snookertable();
        
    }
    MYDATABASE db=new MYDATABASE();
    public void crickettable(){
           ResultSet rs=db.getcricketmembers();
           try{
               while(rs.next()){
               String data[]={rs.getString("NAME"),rs.getString("FATHERNAME"),rs.getString("CONTACT"),rs.getString("DEPARTMENT"),rs.getString("STUDENTID"),rs.getString("MEMBERID"),rs.getString("AGE"),rs.getString("GENDER"),rs.getString("SPORTSELECTED"),rs.getString("EMAIL"),rs.getString("PAYMENT")};
               DefaultTableModel tbModel=(DefaultTableModel)jTable1.getModel();
               tbModel.addRow(data);
               }    
           }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
           }
       }
       public void footballtable(){
           ResultSet rs=db.getfootballmembers();
           try{
             while(rs.next()){
               String data[]={rs.getString("NAME"),rs.getString("FATHERNAME"),rs.getString("CONTACT"),rs.getString("DEPARTMENT"),rs.getString("STUDENTID"),rs.getString("MEMBERID"),rs.getString("AGE"),rs.getString("GENDER"),rs.getString("SPORTSELECTED"),rs.getString("EMAIL"),rs.getString("PAYMENT")};
               DefaultTableModel tbModel=(DefaultTableModel)jTable1.getModel();
               tbModel.addRow(data);
               }  
           }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
           }
       }
        public void hockeytable(){
           ResultSet rs=db.gethockeymembers();
           try{
               while(rs.next()){
               String data[]={rs.getString("NAME"),rs.getString("FATHERNAME"),rs.getString("CONTACT"),rs.getString("DEPARTMENT"),rs.getString("STUDENTID"),rs.getString("MEMBERID"),rs.getString("AGE"),rs.getString("GENDER"),rs.getString("SPORTSELECTED"),rs.getString("EMAIL"),rs.getString("PAYMENT")};
               DefaultTableModel tbModel=(DefaultTableModel)jTable1.getModel();
               tbModel.addRow(data);
               }  
           }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
           }
       }
        public void swimmingtable(){
        ResultSet rs = db.getswimmingmembers();
        try{
               while(rs.next()){
               String data[]={rs.getString("NAME"),rs.getString("FATHERNAME"),rs.getString("CONTACT"),rs.getString("DEPARTMENT"),rs.getString("STUDENTID"),rs.getString("MEMBERID"),rs.getString("AGE"),rs.getString("GENDER"),rs.getString("SPORTSELECTED"),rs.getString("EMAIL"),rs.getString("PAYMENT")};
               DefaultTableModel tbModel=(DefaultTableModel)jTable1.getModel();
               tbModel.addRow(data);
               }    
           }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
           }
    }
    
    public void badmintontable(){
         ResultSet rs = db.getbadmintonmembers();
        try{
               while(rs.next()){
               String data[]={rs.getString("NAME"),rs.getString("FATHERNAME"),rs.getString("CONTACT"),rs.getString("DEPARTMENT"),rs.getString("STUDENTID"),rs.getString("MEMBERID"),rs.getString("AGE"),rs.getString("GENDER"),rs.getString("SPORTSELECTED"),rs.getString("EMAIL"),rs.getString("PAYMENT")};
               DefaultTableModel tbModel=(DefaultTableModel)jTable1.getModel();
               tbModel.addRow(data);
               }    
           }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
           }
    }
    
    public void snookertable(){
        ResultSet rs = db.getsnookermembers();
        try{
               while(rs.next()){
               String data[]={rs.getString("NAME"),rs.getString("FATHERNAME"),rs.getString("CONTACT"),rs.getString("DEPARTMENT"),rs.getString("STUDENTID"),rs.getString("MEMBERID"),rs.getString("AGE"),rs.getString("GENDER"),rs.getString("SPORTSELECTED"),rs.getString("EMAIL"),rs.getString("PAYMENT")};
               DefaultTableModel tbModel=(DefaultTableModel)jTable1.getModel();
               tbModel.addRow(data);
               }    
           }catch(Exception e){
               JOptionPane.showMessageDialog(null, e);
           }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        REMOVEPLAYER = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        REMOVEPLAYER2 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        INF = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        EDNAME = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        EDCONTACT = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        EDFNAME = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        EDDEPART = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        EDSPORTSS = new javax.swing.JTextField();
        EDGENDER = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        EDAGE = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        EDPAYMENT = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        EDEMAIL = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        INFF = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NAME", "FATHERNAME", "CONTACT", "DEPARTMENT", "STUDENTID", "MEMBERID", "AGE", "GENDER", "SPORTSELECTED", "EMAIL", "PAYMENT"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 1210, 250));

        jLabel2.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 51));
        jLabel2.setText("PLAYER MANAGEMENT");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/ww.jpg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, 440, 70));

        jButton1.setBackground(new java.awt.Color(0, 153, 153));
        jButton1.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/delete.png"))); // NOI18N
        jButton1.setText("REMOVE PLAYER");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, 280, -1));

        jButton2.setBackground(new java.awt.Color(0, 153, 153));
        jButton2.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/reset.png"))); // NOI18N
        jButton2.setText("UPDATE/SEARCH");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 370, -1, -1));

        jButton3.setBackground(new java.awt.Color(0, 153, 153));
        jButton3.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/exit.png"))); // NOI18N
        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 20, -1, 30));

        jButton4.setBackground(new java.awt.Color(0, 153, 153));
        jButton4.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/logout.png"))); // NOI18N
        jButton4.setText("LOGOUT");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 20, 160, 30));

        jPanel2.setLayout(null);

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/close.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5);
        jButton5.setBounds(220, 10, 30, 29);

        REMOVEPLAYER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                REMOVEPLAYERActionPerformed(evt);
            }
        });
        jPanel2.add(REMOVEPLAYER);
        REMOVEPLAYER.setBounds(10, 80, 100, 40);

        jLabel6.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel6.setText("STUDENT ID");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(10, 40, 120, 30);

        jButton7.setBackground(new java.awt.Color(0, 153, 153));
        jButton7.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/delete.png"))); // NOI18N
        jButton7.setText("REMOVE");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7);
        jButton7.setBounds(60, 130, 140, 30);

        jLabel18.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel18.setText("SPORT");
        jPanel2.add(jLabel18);
        jLabel18.setBounds(150, 39, 70, 30);
        jPanel2.add(REMOVEPLAYER2);
        REMOVEPLAYER2.setBounds(150, 80, 100, 40);

        jLabel19.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel19.setText("+");
        jPanel2.add(jLabel19);
        jLabel19.setBounds(120, 80, 20, 32);

        jLabel4.setIcon(new javax.swing.ImageIcon("D:\\Java frame\\s5.jpg")); // NOI18N
        jPanel2.add(jLabel4);
        jLabel4.setBounds(0, 0, 260, 210);

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 420, 260, 210));

        jPanel3.setLayout(null);

        jButton6.setBackground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/close.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6);
        jButton6.setBounds(530, 10, 30, 29);

        jLabel7.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        jLabel7.setText("STUDENT ID ");
        jPanel3.add(jLabel7);
        jLabel7.setBounds(0, 10, 85, 30);

        INF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INFActionPerformed(evt);
            }
        });
        jPanel3.add(INF);
        INF.setBounds(90, 10, 90, 30);

        jButton8.setBackground(new java.awt.Color(255, 255, 255));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/close.png"))); // NOI18N
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton8);
        jButton8.setBounds(390, 10, 30, 29);

        jButton9.setBackground(new java.awt.Color(255, 255, 255));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/search.png"))); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton9);
        jButton9.setBounds(350, 10, 30, 30);

        jLabel8.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        jLabel8.setText("NAME");
        jPanel3.add(jLabel8);
        jLabel8.setBounds(0, 50, 50, 30);
        jPanel3.add(EDNAME);
        EDNAME.setBounds(60, 50, 110, 30);

        jLabel9.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel9.setText("FATHER NAME");
        jPanel3.add(jLabel9);
        jLabel9.setBounds(170, 40, 100, 50);

        EDCONTACT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDCONTACTActionPerformed(evt);
            }
        });
        jPanel3.add(EDCONTACT);
        EDCONTACT.setBounds(450, 50, 110, 30);

        jLabel10.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel10.setText("CONTACT");
        jPanel3.add(jLabel10);
        jLabel10.setBounds(380, 50, 70, 30);

        EDFNAME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDFNAMEActionPerformed(evt);
            }
        });
        jPanel3.add(EDFNAME);
        EDFNAME.setBounds(260, 50, 110, 30);

        jLabel11.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel11.setText("DEPART");
        jPanel3.add(jLabel11);
        jLabel11.setBounds(0, 90, 70, 30);
        jPanel3.add(EDDEPART);
        EDDEPART.setBounds(60, 90, 110, 30);

        jLabel12.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel12.setText("SPORTS");
        jPanel3.add(jLabel12);
        jLabel12.setBounds(0, 130, 60, 30);

        jButton10.setBackground(new java.awt.Color(0, 153, 153));
        jButton10.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/reset.png"))); // NOI18N
        jButton10.setText("EDIT");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton10);
        jButton10.setBounds(260, 170, 120, 30);

        jLabel13.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel13.setText("GENDER");
        jPanel3.add(jLabel13);
        jLabel13.setBounds(380, 90, 60, 30);
        jPanel3.add(EDSPORTSS);
        EDSPORTSS.setBounds(60, 130, 110, 30);

        EDGENDER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDGENDERActionPerformed(evt);
            }
        });
        jPanel3.add(EDGENDER);
        EDGENDER.setBounds(450, 90, 110, 30);

        jLabel14.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel14.setText("AGE");
        jPanel3.add(jLabel14);
        jLabel14.setBounds(200, 90, 30, 30);
        jPanel3.add(EDAGE);
        EDAGE.setBounds(260, 90, 110, 30);

        jLabel15.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel15.setText("PAYMENT");
        jPanel3.add(jLabel15);
        jLabel15.setBounds(380, 130, 70, 30);

        EDPAYMENT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDPAYMENTActionPerformed(evt);
            }
        });
        jPanel3.add(EDPAYMENT);
        EDPAYMENT.setBounds(450, 130, 110, 30);

        jLabel16.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel16.setText("EMAIL");
        jPanel3.add(jLabel16);
        jLabel16.setBounds(200, 130, 40, 30);

        EDEMAIL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDEMAILActionPerformed(evt);
            }
        });
        jPanel3.add(EDEMAIL);
        EDEMAIL.setBounds(260, 130, 110, 30);

        jLabel17.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        jLabel17.setText("SPORTS");
        jPanel3.add(jLabel17);
        jLabel17.setBounds(180, 10, 70, 30);
        jPanel3.add(INFF);
        INFF.setBounds(240, 10, 100, 30);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel3.add(jLabel5);
        jLabel5.setBounds(0, 0, 570, 210);

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 420, 570, 210));

        jLabel1.setIcon(new javax.swing.ImageIcon("D:\\Java frame\\Untitled ali.png")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 1030));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1265, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 738, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.hide();
        PLAYERS p=new PLAYERS();
        p.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        this.hide();
        ADMINLOGIN A=new ADMINLOGIN();
        A.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jPanel2.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jPanel3.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jPanel2.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        jPanel3.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void INFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_INFActionPerformed

    private void EDCONTACTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDCONTACTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EDCONTACTActionPerformed

    private void EDGENDERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDGENDERActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EDGENDERActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
       jTable1.setModel(new DefaultTableModel(null,new String[]{"NAME","FATHERNAME","CONTACT","DEPARTMENT","STUDENTID","MEMBERID","AGE","GENDER","SPORTSELECTED","EMAIL","PAYMENT"}));
       crickettable();
       footballtable();
       hockeytable();
       swimmingtable();
       badmintontable();
       snookertable();
           INF.setText("");
           INFF.setText("");
           EDNAME.setText("");
           EDFNAME.setText("");
           EDCONTACT.setText("");
           EDDEPART.setText("");
           EDAGE.setText("");
           EDGENDER.setText("");
           EDSPORTSS.setText("");
           EDEMAIL.setText("");
           EDPAYMENT.setText("");
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
       if(INF.getText().equals("")||INFF.getText().equals("")){
            JOptionPane.showMessageDialog(null, "BOTH FIELDS ARE MANDATORY");
        }
        else{
           
           try{
            
           ResultSet rs=db.searchPlayers(INF.getText(),INFF.getText());
           if(rs.next()){
           
           String data[]={rs.getString("NAME"),rs.getString("FATHERNAME"),rs.getString("CONTACT"),rs.getString("DEPARTMENT"),rs.getString("STUDENTID"),rs.getString("MEMBERID"),rs.getString("AGE"),rs.getString("GENDER"),rs.getString("SPORTSELECTED"),rs.getString("EMAIL"),rs.getString("PAYMENT")};
           DefaultTableModel t=(DefaultTableModel)jTable1.getModel();
           t.setRowCount(0);
           t.addRow(data);
           
                      }
           else{
           
           JOptionPane.showMessageDialog(this, "NO RESULTS FOUND");
               INF.setText(null);
               INFF.setText(null);
           }
              
           }catch(Exception e){
                   System.out.println(e);
           }
        
        }
              

    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        db.updatePLAYERS(INF.getText(),INFF.getText(), EDNAME.getText(), EDFNAME.getText(), Double.parseDouble(EDCONTACT.getText()), EDDEPART.getText(), EDAGE.getText(), EDGENDER.getText(), EDSPORTSS.getText(), EDEMAIL.getText(), EDPAYMENT.getText());
        JOptionPane.showMessageDialog(null,"EDITED SUCCESSFULLY");
        DefaultTableModel t=(DefaultTableModel)jTable1.getModel();
        t.setRowCount(0);
        crickettable();
        footballtable();
        hockeytable();
        swimmingtable();
        badmintontable();
        snookertable();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        ResultSet rs=db.searchPlayers(REMOVEPLAYER.getText(),REMOVEPLAYER2.getText());
            
          try{
              if(REMOVEPLAYER.getText().equals("") || REMOVEPLAYER2.getText().equals("")){
                  JOptionPane.showMessageDialog(null, "BOTH FIELDS ARE MANDATORY");
              }
              else if(rs.next()==(false)){
                  JOptionPane.showMessageDialog(null, "NO RECORDS FOUND");
                  REMOVEPLAYER.setText(null);
              }
              else{
                db.removePlayer(REMOVEPLAYER.getText(),REMOVEPLAYER2.getText());
                REMOVEPLAYER.setText(null);
                REMOVEPLAYER2.setText(null);
                DefaultTableModel t=(DefaultTableModel)jTable1.getModel();
                t.setRowCount(0);
                crickettable();
                footballtable();
                hockeytable();
                swimmingtable();
                badmintontable();
                snookertable();
              }
          }catch(Exception e){
              
          }
           
              
    }//GEN-LAST:event_jButton7ActionPerformed

    private void REMOVEPLAYERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_REMOVEPLAYERActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_REMOVEPLAYERActionPerformed

    private void EDFNAMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDFNAMEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EDFNAMEActionPerformed

    private void EDEMAILActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDEMAILActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EDEMAILActionPerformed

    private void EDPAYMENTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDPAYMENTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EDPAYMENTActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int i = jTable1.getSelectedRow();
        TableModel model = jTable1.getModel();
        EDNAME.setText(model.getValueAt(i, 0).toString());
        EDFNAME.setText(model.getValueAt(i, 1).toString());
        EDCONTACT.setText(model.getValueAt(i, 2).toString());
        EDDEPART.setText(model.getValueAt(i, 3).toString());
        INF.setText(model.getValueAt(i, 4).toString());
        INFF.setText(model.getValueAt(i, 8).toString());
        EDAGE.setText(model.getValueAt(i, 6).toString());
        EDGENDER.setText(model.getValueAt(i, 7).toString());
        EDSPORTSS.setText(model.getValueAt(i, 8).toString());
        EDEMAIL.setText(model.getValueAt(i, 9).toString());
        EDPAYMENT.setText(model.getValueAt(i, 10).toString());
        
    }//GEN-LAST:event_jTable1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PLAYERPURPOSE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PLAYERPURPOSE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PLAYERPURPOSE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PLAYERPURPOSE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PLAYERPURPOSE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField EDAGE;
    private javax.swing.JTextField EDCONTACT;
    private javax.swing.JTextField EDDEPART;
    private javax.swing.JTextField EDEMAIL;
    private javax.swing.JTextField EDFNAME;
    private javax.swing.JTextField EDGENDER;
    private javax.swing.JTextField EDNAME;
    private javax.swing.JTextField EDPAYMENT;
    private javax.swing.JTextField EDSPORTSS;
    private javax.swing.JTextField INF;
    private javax.swing.JTextField INFF;
    private javax.swing.JTextField REMOVEPLAYER;
    private javax.swing.JTextField REMOVEPLAYER2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
