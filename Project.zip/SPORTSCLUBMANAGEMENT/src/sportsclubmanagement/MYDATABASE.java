
package sportsclubmanagement;

import java.sql.*;
import javax.swing.JOptionPane;

public class MYDATABASE {
    
    private Connection con;
    private Statement st;
    private ResultSet rs;
    
    MYDATABASE(){
        try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
        st=con.createStatement();
        System.out.println("DB connected");
        }catch(Exception e){
            System.out.println(e);
        }
    }
 
    public void AddSports(String ADDID, String ADDNAME, int ADDFEE,String ADDTIME){
        
        try{    
        String query="insert into sports(SPORTSID,SPORTSNAME,SPORTSFEE,SPORTSTIMING)values('"+ADDID+"','"+ADDNAME+"','"+ADDFEE+"','"+ADDTIME+"')";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"USE A DIFFERENT ID");
        }
    }
    
    public void DeleteSport(String REMID){
        try{
        String query="delete from sports where SPORTSID='"+REMID+"' ";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"DELETED SUCCESSFULLY");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
            
    }
    
    public ResultSet getSports(){
        try{
        String query="Select * from sports";
        rs=st.executeQuery(query);
        }catch(Exception e){
            System.out.println(e);
            
        }
        return rs;
    }
    
    public ResultSet SearchSports(String SID){
        try{
        String query="Select * from sports where SPORTSID like '"+SID+"'";       
        rs=st.executeQuery(query);
        }catch(Exception e){
            System.out.println(e);
            
        }
        return rs;
    }
    public void UpdateSport(String SID, String EDNAME,int EDFEE,String EDTIME){
        try{
        String query="Update sports set SPORTSNAME='"+EDNAME+"',SPORTSFEE='"+EDFEE+"',SPORTSTIMING='"+EDTIME+"' where SPORTSID='"+SID+"'";
        st.executeUpdate(query);
        }catch(Exception e){
            System.out.println(e);
            
        }    
    }
   
    public void ADDSTAFF(String STAFFID,String STAFFNAME,String DOB,double STAFFNUMBER,String STAFFADDRESS,int STAFFSALARY,String STAFFJOINDATE,String STAFFTYPE,String STAFFSP){
 
        try{
            String query="insert into staffs(STAFFID,NAME,DATEOFBIRTH,NUMBER,ADDRESS,SALARY,JOININGDATE,TYPE,COACHINGSPORT)values('"+STAFFID+"','"+STAFFNAME+"','"+DOB+"','"+STAFFNUMBER+"','"+STAFFADDRESS+"','"+STAFFSALARY+"','"+STAFFJOINDATE+"','"+STAFFTYPE+"','"+STAFFSP+"')";
            st.executeUpdate(query);
            JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,"USE A DIFFERENT ID");
        }
        
    }
    
    public ResultSet getSTAFF(){
        try{
            String query="Select * from staffs";
            rs=st.executeQuery(query);
            
        }catch(Exception e){
            
        }
        return rs;
    }
    
    public void DeleteStaff(String REMSTAFF){
         try{
        String query="delete from staffs where STAFFID='"+REMSTAFF+"' ";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"DELETED SUCCESSFULLY");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }
    
    public ResultSet searchstaff(String EDSTID){
        try{
        String query="Select * from staffs where STAFFID like '"+EDSTID+"'";       
        rs=st.executeQuery(query);
        }catch(Exception e){
            System.out.println(e);
            
        }
        return rs;
    }
    
    public void UpdateStaff(String EDSTAFFID,String EDSTAFFNAME,String EDSTAFFDOB,double EDSTAFFNUMBER,String EDSTAFFADDRESS,int EDSTAFFSALARY,String EDSTAFFJOINDATE,String EDSTAFFTYPE,String EDSTAFFSP){
        try{
        String query="UPDATE staffs SET NAME='"+EDSTAFFNAME+"',DATEOFBIRTH='"+EDSTAFFDOB+"',NUMBER='"+EDSTAFFNUMBER+"',ADDRESS='"+EDSTAFFADDRESS+"',SALARY='"+EDSTAFFSALARY+"',JOININGDATE='"+EDSTAFFJOINDATE+"',TYPE='"+EDSTAFFTYPE+"',COACHINGSPORT='"+EDSTAFFSP+"' WHERE STAFFID='"+EDSTAFFID+"'";
        st.executeUpdate(query);
        }catch(Exception e){
            
        }
    }
    
    public void ADDINCRICKET(String NAME,String FNAME, double CONTACT,String DEPT,String ID,String MEMID,int AGE, String GENDER, String SPORTSS, String EMAIL, String PAYMENT){
        try{
        String query="insert into cricketmembers(NAME, FATHERNAME, CONTACT,DEPARTMENT, STUDENTID,MEMBERID, AGE, GENDER, SPORTSELECTED, EMAIL, PAYMENT) VALUES ('"+NAME+"','"+FNAME+"','"+CONTACT+"','"+DEPT+"','"+ID+"','"+MEMID+"','"+AGE+"','"+GENDER+"','"+SPORTSS+"','"+EMAIL+"','"+PAYMENT+"')";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"DUPLICATE ID ERROR");
        }
    }
    public ResultSet getcricketmembers(){
        try{
            String query="Select * from cricketmembers";
            rs=st.executeQuery(query);
            
        }catch(Exception e){
            
        }
        return rs;
    }
    
    public void ADDINFOOTBALL(String NAME,String FNAME, double CONTACT,String DEPT,String ID,String MEMID,int AGE, String GENDER, String SPORTSS, String EMAIL, String PAYMENT){
        try{
            String query="insert into footballmembers(NAME, FATHERNAME, CONTACT,DEPARTMENT, STUDENTID,MEMBERID, AGE, GENDER, SPORTSELECTED, EMAIL, PAYMENT) VALUES ('"+NAME+"','"+FNAME+"','"+CONTACT+"','"+DEPT+"','"+ID+"','"+MEMID+"','"+AGE+"','"+GENDER+"','"+SPORTSS+"','"+EMAIL+"','"+PAYMENT+"')";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"DUPLICATE ID ERROR");
        }
    }
    public ResultSet getfootballmembers(){
        try{
            String query="Select * from footballmembers";
            rs=st.executeQuery(query);
            
        }catch(Exception e){
            
        }
        return rs;
    }
    public void ADDINHOCKEY(String NAME,String FNAME, double CONTACT,String DEPT,String ID,String MEMID,int AGE, String GENDER, String SPORTSS, String EMAIL, String PAYMENT){
        try{
        String query="insert into hockeymembers(NAME, FATHERNAME, CONTACT,DEPARTMENT, STUDENTID,MEMBERID, AGE, GENDER, SPORTSELECTED, EMAIL, PAYMENT) VALUES ('"+NAME+"','"+FNAME+"','"+CONTACT+"','"+DEPT+"','"+ID+"','"+MEMID+"','"+AGE+"','"+GENDER+"','"+SPORTSS+"','"+EMAIL+"','"+PAYMENT+"')";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
         JOptionPane.showMessageDialog(null,"DUPLICATE ID ERROR");        }
    }
    public ResultSet gethockeymembers(){
        try{
            String query="Select * from hockeymembers";
            rs=st.executeQuery(query);
            
        }catch(Exception e){
            
        }
        return rs;
    }
    
    public void ADDINSWIMMING(String NAME,String FNAME, double CONTACT,String DEPT,String ID,String MEMID,int AGE, String GENDER, String SPORTSS, String EMAIL, String PAYMENT){
        try{
        String query="INSERT INTO `swimmingmembers`(`NAME`, `FATHERNAME`, `CONTACT`, `DEPARTMENT`, `STUDENTID`, `MEMBERID`, `AGE`, `GENDER`, `SPORTSELECTED`, `EMAIL`, `PAYMENT`) VALUES ('"+NAME+"','"+FNAME+"','"+CONTACT+"','"+DEPT+"','"+ID+"','"+MEMID+"','"+AGE+"','"+GENDER+"','"+SPORTSS+"','"+EMAIL+"','"+PAYMENT+"')";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
         JOptionPane.showMessageDialog(null,"DUPLICATE ID ERROR A");        }
    }
    public ResultSet getswimmingmembers(){
        try{
            String query="Select * from swimmingmembers";
            rs=st.executeQuery(query);
            
        }catch(Exception e){
            
        }
        return rs;
    }
    
    public void ADDINBADMINTON(String NAME,String FNAME, double CONTACT,String DEPT,String ID,String MEMID,int AGE, String GENDER, String SPORTSS, String EMAIL, String PAYMENT){
        try{
        String query="insert into badmintonmembers(NAME, FATHERNAME, CONTACT,DEPARTMENT, STUDENTID,MEMBERID, AGE, GENDER, SPORTSELECTED, EMAIL, PAYMENT) VALUES ('"+NAME+"','"+FNAME+"','"+CONTACT+"','"+DEPT+"','"+ID+"','"+MEMID+"','"+AGE+"','"+GENDER+"','"+SPORTSS+"','"+EMAIL+"','"+PAYMENT+"')";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
         JOptionPane.showMessageDialog(null,"DUPLICATE ID ERROR B");        }
    }
    public ResultSet getbadmintonmembers(){
        try{
            String query="Select * from badmintonmembers";
            rs=st.executeQuery(query);
            
        }catch(Exception e){
            
        }
        return rs;
    }
    
    public void ADDINSNOOKER(String NAME,String FNAME, double CONTACT,String DEPT,String ID,String MEMID,int AGE, String GENDER, String SPORTSS, String EMAIL, String PAYMENT){
        try{
        String query="insert into snookermembers(NAME, FATHERNAME, CONTACT,DEPARTMENT, STUDENTID,MEMBERID, AGE, GENDER, SPORTSELECTED, EMAIL, PAYMENT) VALUES ('"+NAME+"','"+FNAME+"','"+CONTACT+"','"+DEPT+"','"+ID+"','"+MEMID+"','"+AGE+"','"+GENDER+"','"+SPORTSS+"','"+EMAIL+"','"+PAYMENT+"')";
        st.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"ADDED SUCCESSFULLY");
        }catch(Exception e){
         JOptionPane.showMessageDialog(null,"DUPLICATE ID ERROR C");        }
    }
    public ResultSet getsnookermembers(){
        try{
            String query="Select * from snookermembers";
            rs=st.executeQuery(query);
            
        }catch(Exception e){
            
        }
        return rs;
    }
    
    public ResultSet searchPlayers(String INF,String INFF){
        try{
        String query="Select * from cricketmembers where cricketmembers.STUDENTID='"+INF+"' AND cricketmembers.SPORTSELECTED='"+INFF+"'  UNION Select * from footballmembers where footballmembers.STUDENTID='"+INF+"' AND footballmembers.SPORTSELECTED='"+INFF+"' UNION Select * from hockeymembers where hockeymembers.STUDENTID='"+INF+"' AND hockeymembers.SPORTSELECTED='"+INFF+"' UNION Select * from swimmingmembers where swimmingmembers.STUDENTID='"+INF+"' AND swimmingmembers.SPORTSELECTED='"+INFF+"' UNION Select * from badmintonmembers where badmintonmembers.STUDENTID='"+INF+"' AND badmintonmembers.SPORTSELECTED='"+INFF+"' UNION Select * from snookermembers where snookermembers.STUDENTID='"+INF+"'AND snookermembers.SPORTSELECTED='"+INFF+"'";
        rs=st.executeQuery(query);
        
        }catch(Exception e){
            System.out.println(e);
    }
      return rs;
    }

    public void removePlayer(String REMOVEPLAYER,String REMOVEPLAYER2){
        try{
            String query="DELETE FROM `cricketmembers` WHERE `STUDENTID`='"+REMOVEPLAYER+"' AND `SPORTSELECTED`='"+REMOVEPLAYER2+"'";
            String query1="DELETE FROM `footballmembers` WHERE `STUDENTID`='"+REMOVEPLAYER+"' AND `SPORTSELECTED`='"+REMOVEPLAYER2+"'";
            String query2="DELETE FROM `hockeymembers` WHERE `STUDENTID`='"+REMOVEPLAYER+"' AND `SPORTSELECTED`='"+REMOVEPLAYER2+"'";
            String query3="DELETE FROM `swimmingmembers` WHERE `STUDENTID`='"+REMOVEPLAYER+"' AND `SPORTSELECTED`='"+REMOVEPLAYER2+"'";
            String query4="DELETE FROM `badmintonmembers` WHERE `STUDENTID`='"+REMOVEPLAYER+"' AND `SPORTSELECTED`='"+REMOVEPLAYER2+"'";
            String query5="DELETE FROM `snookermembers` WHERE `STUDENTID`='"+REMOVEPLAYER+"' AND `SPORTSELECTED`='"+REMOVEPLAYER2+"'";
            st.executeUpdate(query);
            st.executeUpdate(query1);
            st.executeUpdate(query2);
            st.executeUpdate(query3);
            st.executeUpdate(query4);
            st.executeUpdate(query5);
            JOptionPane.showMessageDialog(null, "DELETED SUCCESSFULLY");
        }catch(Exception e){
            System.out.println(e);
        }
    }
   
    public void updatePLAYERS(String INF,String INFF,String EDNAME,String EDFNAME,double EDCONTACT,String EDDEPART,String EDAGE,String EDGENDER,String EDSPORTSS,String EDEMAIL,String EDPAYMENT){
        try{
                String query="UPDATE `cricketmembers` SET cricketmembers.NAME='"+EDNAME+"',cricketmembers.FATHERNAME='"+EDFNAME+"',cricketmembers.CONTACT='"+EDCONTACT+"',cricketmembers.DEPARTMENT='"+EDDEPART+"',cricketmembers.AGE='"+EDAGE+"',cricketmembers.GENDER='"+EDGENDER+"',cricketmembers.SPORTSELECTED='"+EDSPORTSS+"',cricketmembers.EMAIL='"+EDEMAIL+"',cricketmembers.PAYMENT='"+EDPAYMENT+"' WHERE cricketmembers.STUDENTID='"+INF+"' AND cricketmembers.SPORTSELECTED='"+INFF+"'";
                String query1="UPDATE `footballmembers` SET footballmembers.NAME='"+EDNAME+"',footballmembers.FATHERNAME='"+EDFNAME+"',footballmembers.CONTACT='"+EDCONTACT+"',footballmembers.DEPARTMENT='"+EDDEPART+"',footballmembers.AGE='"+EDAGE+"',footballmembers.GENDER='"+EDGENDER+"',footballmembers.SPORTSELECTED='"+EDSPORTSS+"',footballmembers.EMAIL='"+EDEMAIL+"',footballmembers.PAYMENT='"+EDPAYMENT+"' WHERE footballmembers.STUDENTID='"+INF+"' AND footballmembers.SPORTSELECTED='"+INFF+"'";
                String query2="UPDATE `hockeymembers` SET hockeymembers.NAME='"+EDNAME+"',hockeymembers.FATHERNAME='"+EDFNAME+"',hockeymembers.CONTACT='"+EDCONTACT+"',hockeymembers.DEPARTMENT='"+EDDEPART+"',hockeymembers.AGE='"+EDAGE+"',hockeymembers.GENDER='"+EDGENDER+"',hockeymembers.SPORTSELECTED='"+EDSPORTSS+"',hockeymembers.EMAIL='"+EDEMAIL+"',hockeymembers.PAYMENT='"+EDPAYMENT+"' WHERE hockeymembers.STUDENTID='"+INF+"' AND hockeymembers.SPORTSELECTED='"+INFF+"'";
                String query3="UPDATE `swimmingmembers` SET swimmingmembers.NAME='"+EDNAME+"',swimmingmembers.FATHERNAME='"+EDFNAME+"',swimmingmembers.CONTACT='"+EDCONTACT+"',swimmingmembers.DEPARTMENT='"+EDDEPART+"',swimmingmembers.AGE='"+EDAGE+"',swimmingmembers.GENDER='"+EDGENDER+"',swimmingmembers.SPORTSELECTED='"+EDSPORTSS+"',swimmingmembers.EMAIL='"+EDEMAIL+"',swimmingmembers.PAYMENT='"+EDPAYMENT+"' WHERE swimmingmembers.STUDENTID='"+INF+"' AND swimmingmembers.SPORTSELECTED='"+INFF+"'";
                String query4="UPDATE `badmintonmembers` SET badmintonmembers.NAME='"+EDNAME+"',badmintonmembers.FATHERNAME='"+EDFNAME+"',badmintonmembers.CONTACT='"+EDCONTACT+"',badmintonmembers.DEPARTMENT='"+EDDEPART+"',badmintonmembers.AGE='"+EDAGE+"',badmintonmembers.GENDER='"+EDGENDER+"',badmintonmembers.SPORTSELECTED='"+EDSPORTSS+"',badmintonmembers.EMAIL='"+EDEMAIL+"',badmintonmembers.PAYMENT='"+EDPAYMENT+"' WHERE badmintonmembers.STUDENTID='"+INF+"' AND badmintonmembers.SPORTSELECTED='"+INFF+"'";
                String query5="UPDATE `snookermembers` SET snookermembers.NAME='"+EDNAME+"',snookermembers.FATHERNAME='"+EDFNAME+"',snookermembers.CONTACT='"+EDCONTACT+"',snookermembers.DEPARTMENT='"+EDDEPART+"',snookermembers.AGE='"+EDAGE+"',snookermembers.GENDER='"+EDGENDER+"',snookermembers.SPORTSELECTED='"+EDSPORTSS+"',snookermembers.EMAIL='"+EDEMAIL+"',snookermembers.PAYMENT='"+EDPAYMENT+"' WHERE snookermembers.STUDENTID='"+INF+"' AND snookermembers.SPORTSELECTED='"+INFF+"'";              
                st.executeUpdate(query);
                st.executeUpdate(query1);
                st.executeUpdate(query2);
                st.executeUpdate(query3);
                st.executeUpdate(query4);
                st.executeUpdate(query5);
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
   
    
    
}
    
    
    
    

