
package sportsclubmanagement;


public class SPORTSCLUBMANAGEMENT {

 
    public static void main(String[] args) {
        
       MYDATABASE db=new MYDATABASE();
        
    }
    
}
