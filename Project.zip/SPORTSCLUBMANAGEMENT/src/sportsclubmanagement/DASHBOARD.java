/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sportsclubmanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Saleem Dabalya
 */
public class DASHBOARD extends javax.swing.JFrame {

    /**
     * Creates new form DASHBOARD
     */
    public DASHBOARD() {
        initComponents();
        this.setResizable(false);
        countSports();
        countStaff();
        countCricket();
        countFootball();
        countHockey();
        countSwimming();
        countBadminton();
        countSnooker();
    }
    
    public void countSports(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(sportsid) FROM sports";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(sportsid)");
                SP.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void countStaff(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(staffid) FROM staffs";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(staffid)");
                ST.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void countCricket(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(memberid) FROM cricketmembers";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(memberid)");
                CR.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void countFootball(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(memberid) FROM footballmembers";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(memberid)");
                FT.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void countHockey(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(memberid) FROM hockeymembers";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(memberid)");
                HK.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void countSwimming(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(memberid) FROM swimmingmembers";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(memberid)");
                SW.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void countBadminton(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(memberid) FROM badmintonmembers";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(memberid)");
                BD.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void countSnooker(){
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/smiclub","root","");
            String query="SELECT COUNT(memberid) FROM snookermembers";
            PreparedStatement pst=con.prepareCall(query);
            ResultSet rs=pst.executeQuery();
            if(rs.next()){
                String sum=rs.getString("COUNT(memberid)");
                SN.setText(sum);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    
    
    
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        FT = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        CR = new javax.swing.JLabel();
        SN = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        SW = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        HK = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        BD = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        SP = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ST = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setBackground(new java.awt.Color(0, 102, 102));
        jButton1.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 30, 130, 40));

        jButton2.setBackground(new java.awt.Color(0, 102, 102));
        jButton2.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jButton2.setText("HOME");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 30, 120, 40));

        jLabel10.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel10.setText("SPORTS");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 160, -1));

        jLabel11.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel11.setText("STAFF");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 210, 130, 60));

        jLabel12.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel12.setText("CRICKET");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 220, 170, 60));

        jLabel13.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel13.setText("FOOTBALL");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 240, -1, -1));

        FT.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(FT, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 130, 80, 80));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 120, 230, 180));

        jLabel14.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel14.setText("SNOOKER");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 510, -1, -1));

        CR.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(CR, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 130, 80, 60));

        SN.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(SN, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 400, 100, 60));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 390, 230, 180));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 120, 220, 180));

        jLabel15.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel15.setText("BADMINTON");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 680, -1, -1));

        jLabel16.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel16.setText("SWIMMING");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 650, -1, -1));

        jLabel17.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel17.setText("HOCKEY");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, 170, -1));

        SW.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(SW, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 560, 100, 70));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jLabel8.setToolTipText("");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, 210, 170));

        HK.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(HK, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 90, 70));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 210, 180));

        BD.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(BD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 600, 90, 70));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 590, 240, 140));

        SP.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(SP, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 80, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 190, 170));

        ST.setFont(new java.awt.Font("Dialog", 3, 48)); // NOI18N
        jPanel1.add(ST, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, 70, 50));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sports Icon Jframe/Icon Sports Jframe/st.jpg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 190, 170));

        jLabel1.setIcon(new javax.swing.ImageIcon("D:\\Java frame\\s3.jpg")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1260, 750));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.hide();
        ADMINLOGIN A=new ADMINLOGIN();
        A.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.hide();
        ALLSETUP A=new ALLSETUP();
        A.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DASHBOARD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BD;
    private javax.swing.JLabel CR;
    private javax.swing.JLabel FT;
    private javax.swing.JLabel HK;
    private javax.swing.JLabel SN;
    private javax.swing.JLabel SP;
    private javax.swing.JLabel ST;
    private javax.swing.JLabel SW;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
